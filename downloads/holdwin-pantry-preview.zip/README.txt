宏穩茶水間｜2026-11-02 網站預覽

解壓縮後用瀏覽器開啟 demo.html。插畫、商品原圖及字體都在檔案內，無須安裝或連網。
桌機為白底工具列與辦公室四門冰箱，手機為單門冰箱。點門拉近後才顯示搜尋和分類。

這是本機可操作預覽，資料只在目前瀏覽器，不會同步 Google。
正式網站：https://reytai-hldwn.github.io/pantry/
原生表單 Google 更新說明：https://github.com/reytai-hldwn/pantry/blob/main/docs/GOOGLE-SETUP.md

一般預覽不包含實際盤點數量。
